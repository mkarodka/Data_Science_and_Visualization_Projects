# Weaviate

Run docker container for PySpark-Jupyter and Weaviate.
$ docker compose up -d

Create data using Dataset Notebooks in work folder.<br>
Use RAG notebook to push data to Weaviate, converting things to vectors and to query Weaviate. 
